package com.tasya.pelangganservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PelangganServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PelangganServiceApplication.class, args);
	}

}
