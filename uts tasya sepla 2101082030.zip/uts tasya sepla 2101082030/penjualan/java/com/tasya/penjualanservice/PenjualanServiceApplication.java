package com.tasya.penjualanservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PenjualanServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PenjualanServiceApplication.class, args);
	}

}
